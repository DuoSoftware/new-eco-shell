angular
.module('mainApp', ['ngMaterial','directivelibrary','ngMdIcons', 'ui.router', 'ngAnimate','angular.filter','uiMicrokernel'])


.config(function($stateProvider, $urlRouterProvider, $httpProvider) {
	
	
	  $httpProvider.defaults.headers.common = {};
  $httpProvider.defaults.headers.post = {};
  $httpProvider.defaults.headers.put = {};
  $httpProvider.defaults.headers.patch = {};

	$urlRouterProvider.otherwise('/market/home');

	$stateProvider

        // HOME STATES AND NESTED VIEWS ========================================

        .state('market', {
        	url: '/market',
        	templateUrl: 'partials/market.html'
        })
		
		.state('market.home', {
        	url: '/home',
        	templateUrl: 'partials/home.html'
        })
		
		.state('market.toprated', {
        	url: '/toprated',
        	templateUrl: 'partials/toprated.html'
        })
		
		.state('market.new_releases', {
			url: '/new_releases',
        	templateUrl: 'partials/new_releases.html'
		})
		
		.state('market.product', {
        	url: '/product',
        	templateUrl: 'partials/product.html',
			controller: 'viewProductCtrl'
        })
		
		.state('myapps', {
        	url: '/myapps',
        	templateUrl: 'partials/myapps.html',
			controller: 'myappsCtrl'
        })
		
		.state('myaccount', {
        	url: '/myaccount',
        	templateUrl: 'partials/myaccount.html',
			controller: 'myaccountCtrl'
        })
		
		


    })

.controller('ViewCtrl', function ($scope,$state, $mdDialog, $window,$http) {
	
	$scope.baseUrl = "http://duoworld.duoweb.info";
	$scope.selectedProduct = "";
	
	$scope.paidOrFree = null;
		
		$scope.changeTab = function(ind){
             switch (ind) {
                case 0:
                    //All Categories
					$scope.paidOrFree = null;
                    break;
                case 1:
                    //$location.url("/paid");
					$scope.paidOrFree = "Paid";
                    break;
				 case 2:
                    $scope.paidOrFree = "Free";
					break;
            }
        };
	
	function defaultColors()
	{
		angular.element('#main').css('background', '#34474E');
		angular.element('#myapps').css('background', '#34474E');
		angular.element('#myaccount').css('background', '#34474E');
		
	}
	
	 //Get the initial letter of the category for applications.
     $scope.getCatLetter=function(catName){
		  try{
		   var catogeryLetter = "img/material alperbert/avatar_tile_"+catName.charAt(0).toLowerCase()+"_28.png";
		 }catch(exception){}
		 return catogeryLetter;
     }; 
	
	$scope.change_ref = function(sref,id)
	{
		defaultColors();
		$state.go(sref);
		angular.element('#'+id).css('background', '#00acc4');
	}
	

	$http.get('js/categories.json').success(function(response) {
		$scope.categories = response;
	});
	$scope.showProgress = false;
	$scope.allApps = [];
	$scope.topRatedApps = [];
	$scope.openCategory = function(name)
	{
		//alert(name);
		location.href = "#/market/home";
		$scope.showProgress = true;
		console.log($scope.baseUrl+"/marketplace/getAppsByCategory/"+name+"/2/3");
		
		$http.get($scope.baseUrl+"/marketplace/getAppsByCategory/"+name+"/2/3")
           .success(function(data) 
           {
                 console.log(data);
				 $scope.allApps = data;
				 
				 for (i = 0, len = $scope.allApps.length; i<len; ++i){
			
						if(!$scope.allApps[i].iconUrl)
						{
							$scope.allApps[i].iconUrl = "img/standard.png";
						}
						
						if(isNaN($scope.allApps[i].price) == false)
						{
							$scope.allApps[i].Paid = "Paid";
						}else if($scope.allApps[i].price == "Free" || $scope.allApps[i].price == 0)
						{
							$scope.allApps[i].Paid = "Free";
						}
					}
				 $scope.showProgress = false;
                
             }).error(function(){
				 console.log(data);
				 $scope.showProgress = false;
            }); 
	}
	
	$scope.goTotopRated = function()
	{
		location.href = "#/market/toprated";
		
		if($scope.topRatedApps.length == 0)
		{
			$http.get($scope.baseUrl+"/marketplace/topRatedApps/")
			   .success(function(data) 
			   {
					 data.forEach(function(item) {
						 if(item.app){
							 if(!item.app.iconUrl)
							{
								item.app.iconUrl = "img/standard.png";
							}
							
							if(isNaN(item.app.price) == false)//if price is a number
							{
								item.app.Paid = "Paid";
							}else if(item.app.price == "Free" || item.app.price == 0 || item.app.price == "0")
							{
								item.app.Paid = "Free";
							}
								$scope.topRatedApps.push(item.app);
								
						 }
					 })
					 console.log($scope.topRatedApps);
					 $scope.showProgress = false;
					
				 }).error(function(){
					 console.log(data);
					 $scope.showProgress = false;
				}); 
		}
	}

	$scope.viewProduct = function(product)
	{
		$scope.selectedProduct = product;
		location.href = '#/market/product';
	}
	
	$scope.back = function()
	{
		
		var boxOne = document.getElementsByClassName('selected_product_card');
			// angular.element(boxOne).css('background-color', 'orange');
			 angular.element(boxOne).addClass('scaleDown');
			 setTimeout(function(){
				location.href = '#/market/home';
			 }, 400);
	}
	
	
	
	$scope.goTonewReleases = function()
	{
		location.href = "#/market/new_releases";
	}
	
	
	
})
.controller('viewProductCtrl', function ($scope,$state, $mdDialog, $window,$http) {
	
	//Configuration for bxslider
		setTimeout(function(){
		  $('.bxslider').bxSlider({
			auto: true,
			speed:800
		  });
		},100);
		
		$scope.rateApp = function(rate, app, ev)
		{
				//console.log(rate, app.appkey);
				var rating = {};
				rating.appkey = app.id;
				rating.userid = "adminXXX923@uoweb.info";
				rating.stars = rate;
				
				$mdDialog.show({
					  controller: 'rateCtrl',
					  templateUrl: 'partials/rate.html',
					  parent: angular.element(document.body),
					  targetEvent: ev,
					  clickOutsideToClose:true,
					  locals: {ratingObject: rating}
				})
		}	
})

.controller('rateCtrl', function ($scope,$mdDialog,ratingObject,$auth, $http) {
	$scope.ratingObject = ratingObject;
	console.log(ratingObject);
	$scope.baseUrl = "http://duoworld.duoweb.info";
	
	$scope.cancel = function()
	{
		$mdDialog.hide();
	}
	
	$scope.submit = function()
	{

		var req = {
			method: 'POST',
			 
			url: $scope.baseUrl+ "/marketplace/addRating",
			   
			headers: {
				 'Content-Type': 'application/json'
				// 'SecurityKey' : $auth.getSecurityToken()
			   },
			   
			//data: $scope.ratingObject
			data : {
				"Name" : "456789098765"
			}
		
		};
		console.log(req);
          
		$http(req).then(function(data)
		{
			console.log(data);
			$mdDialog.hide();
			
			console.log('success');
		
		}, 
		function(data)
		{
			console.log("Fail");
	
		});
		
	}
	

})

.controller('myappsCtrl', function ($scope,$state, $mdDialog, $window,$http) {
	
	
})



.filter('ceil', function() {
	  return function(input) {
		var input = input || 0;
		return Math.ceil(input);
	  };
	});

function DialogController($scope, $mdDialog) {

  $scope.cancel = function() {
    $mdDialog.cancel();
  };
  $scope.answer = function() {
	  
    alert(document.getElementById('direct-link'));
  };
}

