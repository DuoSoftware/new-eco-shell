/**
 * Angular Material still lacks some components. This project aims to bring those missing components.
 * directive-library build:01-20-2016
 * Last update: For App Market
**/

(function($angular) {
var directiveLibraryModule = angular.module('directivelibrary',[]); //'uiMicrokernel',

/*
_____  ___  _____ __ __  __  ____     ____   ___  _____      __ _____  ___  _____ _____ 
||_// ||=||  ||   || ||\\|| (( ___    ||=)  ||=|| ||_//     ((   ||   ||=|| ||_//  ||   
|| \\ || ||  ||   || || \||  \\_||    ||_)) || || || \\    \_))  ||   || || || \\  || 
*/
directiveLibraryModule.directive('starRating', function () {
		return {
			scope: {
				rating: '=',
				colour: '=',
				maxRating: '@',
				readOnly: '@',
				click: "&",
				mouseHover: "&",
				mouseLeave: "&"
			},
			template:
				"<div style='display: inline-block; margin: 0px; padding: 0px; cursor:pointer; font-size:1.5em' ng-repeat='idx in maxRatings track by $index'> \
						<md-icon style='color:white;height:20px;width:20px;outline:0' md-svg-src='{{((hoverValue + _rating) <= $index) && \"img/directive_library/ic_star_outline_24px.svg\" || \"img/directive_library/ic_star_24px.svg\"}}'\
						ng-Click='isolatedClick($index + 1)'\
						ng-mouseenter='isolatedMouseHover($index + 1)'\
						ng-mouseleave='isolatedMouseLeave($index + 1)'></md-icon>\
				</div>",
			compile: function (element, attrs) {
				if (!attrs.maxRating || (Number(attrs.maxRating) <= 0)) {
					attrs.maxRating = '5';
				};
			},
			controller: function ($scope) {
				$scope.maxRatings = [];

				for (var i = 1; i <= $scope.maxRating; i++) {
					$scope.maxRatings.push({});
				};

				$scope._rating = $scope.rating;

				$scope.isolatedClick = function (param) {
					if ($scope.readOnly == 'true') return;

					$scope.rating = $scope._rating = param;
					$scope.hoverValue = 0;
					$scope.click({ param: param });
				};

				$scope.isolatedMouseHover = function (param) {
					if ($scope.readOnly == 'true') return;

					$scope._rating = 0;
					$scope.hoverValue = param;
					$scope.mouseHover({ param: param });
				};

				$scope.isolatedMouseLeave = function (param) {
					if ($scope.readOnly == 'true') return;

					$scope._rating = $scope.rating;
					$scope.hoverValue = 0;
					$scope.mouseLeave({ param: param });
				};
			}
		};
	});

	
	directiveLibraryModule.directive('starRatingTwo', function () {
		return {
			scope: {
				rating: '=',
				colour: '=',
				maxRating: '@',
				readOnly: '@',
				click: "&",
				mouseHover: "&",
				mouseLeave: "&"
			},
			template:
				"<div style='display: inline-block; margin: 0px; padding: 0px; cursor:pointer; font-size:1.5em' ng-repeat='idx in maxRatings track by $index'> \
						<md-icon style='color:gold;height:40px;width:40px;outline:0' md-svg-src='{{((hoverValue + _rating) <= $index) && \"img/directive_library/ic_star_outline_24px.svg\" || \"img/directive_library/ic_star_24px.svg\"}}'\
						ng-Click='isolatedClick($index + 1)'\
						ng-mouseenter='isolatedMouseHover($index + 1)'\
						ng-mouseleave='isolatedMouseLeave($index + 1)'></md-icon>\
				</div>",
			compile: function (element, attrs) {
				if (!attrs.maxRating || (Number(attrs.maxRating) <= 0)) {
					attrs.maxRating = '5';
				};
			},
			controller: function ($scope) {
				$scope.maxRatings = [];

				for (var i = 1; i <= $scope.maxRating; i++) {
					$scope.maxRatings.push({});
				};

				$scope._rating = $scope.rating;

				$scope.isolatedClick = function (param) {
					if ($scope.readOnly == 'true') return;

					$scope.rating = $scope._rating = param;
					$scope.hoverValue = 0;
					$scope.click({ param: param });
				};

				$scope.isolatedMouseHover = function (param) {
					if ($scope.readOnly == 'true') return;

					$scope._rating = 0;
					$scope.hoverValue = param;
					$scope.mouseHover({ param: param });
				};

				$scope.isolatedMouseLeave = function (param) {
					if ($scope.readOnly == 'true') return;

					$scope._rating = $scope.rating;
					$scope.hoverValue = 0;
					$scope.mouseLeave({ param: param });
				};
			}
		};
	});

/*
_____  ___  _____ __ __  __  ____     ____   ___  _____    _____ __ __  __ __   __ __  __ 
||_// ||=||  ||   || ||\\|| (( ___    ||=)  ||=|| ||_//    ||==  || ||\\|| ||  ((  ||==|| 
|| \\ || ||  ||   || || \||  \\_||    ||_)) || || || \\    ||    || || \|| || \_)) ||  ||
*/	  

/*
  _                _                                   _   _                                       _             _   
 | |__   __ _  ___| | ____ _ _ __ ___  _   _ _ __   __| | | |__   __ _ _ __  _ __   ___ _ __   ___| |_ __ _ _ __| |_ 
 | '_ \ / _` |/ __| |/ / _` | '__/ _ \| | | | '_ \ / _` | | '_ \ / _` | '_ \| '_ \ / _ \ '__| / __| __/ _` | '__| __|
 | |_) | (_| | (__|   < (_| | | | (_) | |_| | | | | (_| | | |_) | (_| | | | | | | |  __/ |    \__ \ || (_| | |  | |_ 
 |_.__/ \__,_|\___|_|\_\__, |_|  \___/ \__,_|_| |_|\__,_| |_.__/ \__,_|_| |_|_| |_|\___|_|    |___/\__\__,_|_|   \__|
                       |___/                                                                                         
*/

	directiveLibraryModule.directive('mdBackgroundBanner', function() {
	  return {
		restrict: 'E',
		template: "<div id='backgound_banner' style='margin:0px; background:{{color}}; position:fixed; height:{{height}}; width:100%; z-index:0;)'></div>",
		//"<div id='prlx_lyr_1' style='position:fixed; background: url() 0px 200px;width:100%;height:800px;'></div> <div id='backgound_banner' style='margin:0px; background:; position:fixed; height:{{height}}; width:100%; z-index:-2; box-shadow:0 3px 1px -2px rgba(0,0,0,.14),0 2px 2px 0 rgba(0,0,0,.098),0 1px 5px 0 rgba(0,0,0,.084);'></div>",
		
		scope:{
			color:'@',
			height:'@'
		},
		link: function(scope,element){

			 if(!scope.color)
			 {
				scope.color = "rgb(98, 203, 143)";
			 }
			 if(!scope.height)
			 {
				scope.height = "230px";
			 }
				
			//parallax scroll effect
			/*
			function parallax(){
			 var prlx_lyr_1 = document.getElementById('prlx_lyr_1');
			 var backgound_banner = document.getElementById('backgound_banner');
			 prlx_lyr_1.style.top = -(window.pageYOffset / 10)+'px';
			 backgound_banner.style.top = -(window.pageYOffset / 25)+'px';
			}
			window.addEventListener("scroll", parallax, false);
			*/
		} //end of link
	  };
	});
	
	/*
	  _                _                                   _   _                                                  _ 
	 | |__   __ _  ___| | ____ _ _ __ ___  _   _ _ __   __| | | |__   __ _ _ __  _ __   ___ _ __    ___ _ __   __| |
	 | '_ \ / _` |/ __| |/ / _` | '__/ _ \| | | | '_ \ / _` | | '_ \ / _` | '_ \| '_ \ / _ \ '__|  / _ \ '_ \ / _` |
	 | |_) | (_| | (__|   < (_| | | | (_) | |_| | | | | (_| | | |_) | (_| | | | | | | |  __/ |    |  __/ | | | (_| |
	 |_.__/ \__,_|\___|_|\_\__, |_|  \___/ \__,_|_| |_|\__,_| |_.__/ \__,_|_| |_|_| |_|\___|_|     \___|_| |_|\__,_|
							|___/                                                                                   
	*/
	
	
	/*
	                _   _               _   _ _   _            _             _   
	  ___  ___  ___| |_(_) ___  _ __   | |_(_) |_| | ___   ___| |_ __ _ _ __| |_ 
	 / __|/ _ \/ __| __| |/ _ \| '_ \  | __| | __| |/ _ \ / __| __/ _` | '__| __|
	 \__ \  __/ (__| |_| | (_) | | | | | |_| | |_| |  __/ \__ \ || (_| | |  | |_ 
	 |___/\___|\___|\__|_|\___/|_| |_|  \__|_|\__|_|\___| |___/\__\__,_|_|   \__|
	*/
	
	directiveLibraryModule.directive('sectionTitle', function() {
	  return {
		restrict: 'E',
		template: "<div id='newdiv' layout='row' style='width: 255px; margin-top:8px; margin-left:8px;' flex layout-sm='row'><div flex='25'>	<img src={{catogeryLetter}} style='margin-top:22px;border-radius:20px'/>	</div> <div flex style='margin-top:27px;'>	<label style='font-weight:700'>{{title}}</label> </div></div>",
		scope:{
			title:'@',
			catogeryLetter:'='
		},
		link: function(scope,element){

      if (scope.title == "" || scope.title == null) {
         
        element.find('#newdiv').attr('hide-sm', '');
        //console.log("one of the pic is empty");
      }else{
        scope.catogeryLetter = "img/material alperbert/avatar_tile_"+scope.title.charAt(0).toLowerCase()+"_28.png";
         
         element.find('#newdiv').attr('new', '');
      }

			
			
			
		} //end of link
	  };
	});
	
	/*
		                _   _               _   _ _   _                       _ 
		  ___  ___  ___| |_(_) ___  _ __   | |_(_) |_| | ___    ___ _ __   __| |
		 / __|/ _ \/ __| __| |/ _ \| '_ \  | __| | __| |/ _ \  / _ \ '_ \ / _` |
		 \__ \  __/ (__| |_| | (_) | | | | | |_| | |_| |  __/ |  __/ | | | (_| |
		 |___/\___|\___|\__|_|\___/|_| |_|  \__|_|\__|_|\___|  \___|_| |_|\__,_|
                                                                        
	*/
	
	
	/*
		  _     _                  _             _   
		 | |__ | |_   _ _ __   ___| |_ __ _ _ __| |_ 
		 | '_ \| | | | | '__| / __| __/ _` | '__| __|
		 | |_) | | |_| | |    \__ \ || (_| | |  | |_ 
		 |_.__/|_|\__,_|_|    |___/\__\__,_|_|   \__|
	*/
	
	//Strat Card background image blur directive
	directiveLibraryModule.directive('blur',function(){
	  return{
		restrict:'E',
		replace:true,
		scope:{
		  id:"@",
		  blurSrc:"@",
		  blurIntensity:"@"
		},
		template:'<canvas id="{{id}}">'
		+'</canvas>',
		link:function(scope,element,attrs){

		  var canvas,context,canvasBackground,width,height;

		  canvas=element[0];
		  width=parseInt(canvas.parentNode.offsetWidth);
		  height=parseInt(canvas.parentNode.offsetHeight);
		  canvas.width=width;
		  canvas.height=height;
		  context=canvas.getContext('2d');
		  canvasBackground = new Image();
		  canvasBackground.src = scope.blurSrc;

		  var drawBlur=function(){
			context.drawImage(canvasBackground, 0, 0, width, height);
			stackBlurCanvasRGBA(attrs.id, 0, 0, width, height, scope.blurIntensity);
		  }

		  canvasBackground.onload=function(){
			drawBlur();
		  }
		}
	  }

	});//End Card background image blur directive

	//This StackBlur.js is needed for the blur directive
	function stackBlurImage(a,t,e,r){var n=document.getElementById(a),l=n.naturalWidth,g=n.naturalHeight,c=document.getElementById(t);c.style.width=l+"px",c.style.height=g+"px",c.width=l,c.height=g;var o=c.getContext("2d");o.clearRect(0,0,l,g),o.drawImage(n,0,0),isNaN(e)||1>e||(r?stackBlurCanvasRGBA(t,0,0,l,g,e):stackBlurCanvasRGB(t,0,0,l,g,e))}function stackBlurCanvasRGBA(a,t,e,r,n,l){if(!(isNaN(l)||1>l)){l|=0;var g,c=document.getElementById(a),o=c.getContext("2d");try{try{g=o.getImageData(t,e,r,n)}catch(s){try{netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead"),g=o.getImageData(t,e,r,n)}catch(s){throw alert("Cannot access local image"),new Error("unable to access local image data: "+s)}}}catch(s){throw alert("Cannot access image"),new Error("unable to access image data: "+s)}var i,u,b,m,f,h,x,d,v,B,w,y,I,C,k,E,R,p,D,N,_,S,G,P,A=g.data,M=l+l+1,U=r-1,H=n-1,W=l+1,j=W*(W+1)/2,q=new BlurStack,z=q;for(b=1;M>b;b++)if(z=z.next=new BlurStack,b==W)var F=z;z.next=q;var J=null,K=null;x=h=0;var L=mul_table[l],O=shg_table[l];for(u=0;n>u;u++){for(E=R=p=D=d=v=B=w=0,y=W*(N=A[h]),I=W*(_=A[h+1]),C=W*(S=A[h+2]),k=W*(G=A[h+3]),d+=j*N,v+=j*_,B+=j*S,w+=j*G,z=q,b=0;W>b;b++)z.r=N,z.g=_,z.b=S,z.a=G,z=z.next;for(b=1;W>b;b++)m=h+((b>U?U:b)<<2),d+=(z.r=N=A[m])*(P=W-b),v+=(z.g=_=A[m+1])*P,B+=(z.b=S=A[m+2])*P,w+=(z.a=G=A[m+3])*P,E+=N,R+=_,p+=S,D+=G,z=z.next;for(J=q,K=F,i=0;r>i;i++)A[h+3]=G=w*L>>O,0!=G?(G=255/G,A[h]=(d*L>>O)*G,A[h+1]=(v*L>>O)*G,A[h+2]=(B*L>>O)*G):A[h]=A[h+1]=A[h+2]=0,d-=y,v-=I,B-=C,w-=k,y-=J.r,I-=J.g,C-=J.b,k-=J.a,m=x+((m=i+l+1)<U?m:U)<<2,E+=J.r=A[m],R+=J.g=A[m+1],p+=J.b=A[m+2],D+=J.a=A[m+3],d+=E,v+=R,B+=p,w+=D,J=J.next,y+=N=K.r,I+=_=K.g,C+=S=K.b,k+=G=K.a,E-=N,R-=_,p-=S,D-=G,K=K.next,h+=4;x+=r}for(i=0;r>i;i++){for(R=p=D=E=v=B=w=d=0,h=i<<2,y=W*(N=A[h]),I=W*(_=A[h+1]),C=W*(S=A[h+2]),k=W*(G=A[h+3]),d+=j*N,v+=j*_,B+=j*S,w+=j*G,z=q,b=0;W>b;b++)z.r=N,z.g=_,z.b=S,z.a=G,z=z.next;for(f=r,b=1;l>=b;b++)h=f+i<<2,d+=(z.r=N=A[h])*(P=W-b),v+=(z.g=_=A[h+1])*P,B+=(z.b=S=A[h+2])*P,w+=(z.a=G=A[h+3])*P,E+=N,R+=_,p+=S,D+=G,z=z.next,H>b&&(f+=r);for(h=i,J=q,K=F,u=0;n>u;u++)m=h<<2,A[m+3]=G=w*L>>O,G>0?(G=255/G,A[m]=(d*L>>O)*G,A[m+1]=(v*L>>O)*G,A[m+2]=(B*L>>O)*G):A[m]=A[m+1]=A[m+2]=0,d-=y,v-=I,B-=C,w-=k,y-=J.r,I-=J.g,C-=J.b,k-=J.a,m=i+((m=u+W)<H?m:H)*r<<2,d+=E+=J.r=A[m],v+=R+=J.g=A[m+1],B+=p+=J.b=A[m+2],w+=D+=J.a=A[m+3],J=J.next,y+=N=K.r,I+=_=K.g,C+=S=K.b,k+=G=K.a,E-=N,R-=_,p-=S,D-=G,K=K.next,h+=r}o.putImageData(g,t,e)}}function stackBlurCanvasRGB(a,t,e,r,n,l){if(!(isNaN(l)||1>l)){l|=0;var g,c=document.getElementById(a),o=c.getContext("2d");try{try{g=o.getImageData(t,e,r,n)}catch(s){try{netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead"),g=o.getImageData(t,e,r,n)}catch(s){throw alert("Cannot access local image"),new Error("unable to access local image data: "+s)}}}catch(s){throw alert("Cannot access image"),new Error("unable to access image data: "+s)}var i,u,b,m,f,h,x,d,v,B,w,y,I,C,k,E,R,p,D,N,_=g.data,S=l+l+1,G=r-1,P=n-1,A=l+1,M=A*(A+1)/2,U=new BlurStack,H=U;for(b=1;S>b;b++)if(H=H.next=new BlurStack,b==A)var W=H;H.next=U;var j=null,q=null;x=h=0;var z=mul_table[l],F=shg_table[l];for(u=0;n>u;u++){for(C=k=E=d=v=B=0,w=A*(R=_[h]),y=A*(p=_[h+1]),I=A*(D=_[h+2]),d+=M*R,v+=M*p,B+=M*D,H=U,b=0;A>b;b++)H.r=R,H.g=p,H.b=D,H=H.next;for(b=1;A>b;b++)m=h+((b>G?G:b)<<2),d+=(H.r=R=_[m])*(N=A-b),v+=(H.g=p=_[m+1])*N,B+=(H.b=D=_[m+2])*N,C+=R,k+=p,E+=D,H=H.next;for(j=U,q=W,i=0;r>i;i++)_[h]=d*z>>F,_[h+1]=v*z>>F,_[h+2]=B*z>>F,d-=w,v-=y,B-=I,w-=j.r,y-=j.g,I-=j.b,m=x+((m=i+l+1)<G?m:G)<<2,C+=j.r=_[m],k+=j.g=_[m+1],E+=j.b=_[m+2],d+=C,v+=k,B+=E,j=j.next,w+=R=q.r,y+=p=q.g,I+=D=q.b,C-=R,k-=p,E-=D,q=q.next,h+=4;x+=r}for(i=0;r>i;i++){for(k=E=C=v=B=d=0,h=i<<2,w=A*(R=_[h]),y=A*(p=_[h+1]),I=A*(D=_[h+2]),d+=M*R,v+=M*p,B+=M*D,H=U,b=0;A>b;b++)H.r=R,H.g=p,H.b=D,H=H.next;for(f=r,b=1;l>=b;b++)h=f+i<<2,d+=(H.r=R=_[h])*(N=A-b),v+=(H.g=p=_[h+1])*N,B+=(H.b=D=_[h+2])*N,C+=R,k+=p,E+=D,H=H.next,P>b&&(f+=r);for(h=i,j=U,q=W,u=0;n>u;u++)m=h<<2,_[m]=d*z>>F,_[m+1]=v*z>>F,_[m+2]=B*z>>F,d-=w,v-=y,B-=I,w-=j.r,y-=j.g,I-=j.b,m=i+((m=u+A)<P?m:P)*r<<2,d+=C+=j.r=_[m],v+=k+=j.g=_[m+1],B+=E+=j.b=_[m+2],j=j.next,w+=R=q.r,y+=p=q.g,I+=D=q.b,C-=R,k-=p,E-=D,q=q.next,h+=r}o.putImageData(g,t,e)}}function BlurStack(){this.r=0,this.g=0,this.b=0,this.a=0,this.next=null}var mul_table=[512,512,456,512,328,456,335,512,405,328,271,456,388,335,292,512,454,405,364,328,298,271,496,456,420,388,360,335,312,292,273,512,482,454,428,405,383,364,345,328,312,298,284,271,259,496,475,456,437,420,404,388,374,360,347,335,323,312,302,292,282,273,265,512,497,482,468,454,441,428,417,405,394,383,373,364,354,345,337,328,320,312,305,298,291,284,278,271,265,259,507,496,485,475,465,456,446,437,428,420,412,404,396,388,381,374,367,360,354,347,341,335,329,323,318,312,307,302,297,292,287,282,278,273,269,265,261,512,505,497,489,482,475,468,461,454,447,441,435,428,422,417,411,405,399,394,389,383,378,373,368,364,359,354,350,345,341,337,332,328,324,320,316,312,309,305,301,298,294,291,287,284,281,278,274,271,268,265,262,259,257,507,501,496,491,485,480,475,470,465,460,456,451,446,442,437,433,428,424,420,416,412,408,404,400,396,392,388,385,381,377,374,370,367,363,360,357,354,350,347,344,341,338,335,332,329,326,323,320,318,315,312,310,307,304,302,299,297,294,292,289,287,285,282,280,278,275,273,271,269,267,265,263,261,259],shg_table=[9,11,12,13,13,14,14,15,15,15,15,16,16,16,16,17,17,17,17,17,17,17,18,18,18,18,18,18,18,18,18,19,19,19,19,19,19,19,19,19,19,19,19,19,19,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24];

	/*
	  _     _                             _ 
	 | |__ | |_   _ _ __    ___ _ __   __| |
	 | '_ \| | | | | '__|  / _ \ '_ \ / _` |
	 | |_) | | |_| | |    |  __/ | | | (_| |
	 |_.__/|_|\__,_|_|     \___|_| |_|\__,_|
	*/
	
	/*
	 ____  _____  _  ____  _  _____  _   ____  _____  ____  ____  _____ 
	/ ___\/__ __\/ \/   _\/ |/ /\  \//  / ___\/__ __\/  _ \/  __\/__ __\
	|    \  / \  | ||  /  |   /  \  /   |    \  / \  | / \||  \/|  / \  
	\___ |  | |  | ||  \_ |   \  / /    \___ |  | |  | |-|||    /  | |  
	\____/  \_/  \_/\____/\_|\_\/_/     \____/  \_/  \_/ \|\_/\_\  \_/
	*/
	
	directiveLibraryModule.directive("sticky", ["$window", function(t) {
        return {
            restrict: "A",
            scope: {
                disabled: "=disabledSticky"
            },
            link: function(e, s, o) {
                function n(e) {
                    return "true" === e ? t.innerHeight - (s[0].offsetHeight + parseInt(z)) < 0 : !1
                }

                function i(t, e, s) {
                    var o = "top",
                        n = Math.abs(t - e),
                        i = Math.abs(t - s);
                    return n > i && (o = "bottom"), o
                }

                function r(t) {
                    s.attr("style", I), g = !1, k.removeClass(y), s.removeClass(b), s.removeClass(b), s.addClass(v), "top" === t ? s.css("z-index", 10).css("width", s[0].offsetWidth).css("top", W.top).css("position", W.position).css("left", W.cssLeft).css("margin-top", W.marginTop).css("height", W.height) : "bottom" === t && M === !0 && s.css("z-index", 10).css("width", s[0].offsetWidth).css("top", "").css("bottom", 0).css("position", "absolute").css("left", W.cssLeft).css("margin-top", W.marginTop).css("margin-bottom", W.marginBottom).css("height", W.height), u && t === H && u.remove()
                }

                function c(t) {
                    g = !0, W.offsetWidth = s[0].offsetWidth, k.addClass(y), s.removeClass(v), s.addClass(b), T && t === H && (u = angular.element("<div>"), u.css("height", s[0].offsetHeight + "px"), s.after(u)), s.css("z-index", "10").css("width", s[0].offsetWidth + "px").css("position", "fixed").css("left", s.css("left").replace("px", "") + "px").css(H, z + a(w) + "px").css("margin-top", 0), "bottom" === H && s.css("margin-bottom", 0)
                }

                function a(t) {
                    var e = 0;
                    return t.getBoundingClientRect && (e = t.getBoundingClientRect().top), e
                }

                function f() {
                    var t;
                    return t = "undefined" != typeof w.scrollTop ? w.scrollTop : "undefined" != typeof w.pageYOffset ? w.pageYOffset : document.documentElement.scrollTop
                }

                function l() {
                    var e;
                    return e = C[0] instanceof HTMLElement ? t.getComputedStyle(C[0], null).getPropertyValue("height").replace(/px;?/, "") : t.innerHeight, parseInt(e) || 0
                }

                function d() {
                    var e = o.mediaQuery || !1,
                        s = t.matchMedia;
                    return e && !(s("(" + e + ")").matches || s(e).matches)
                }
                var p, m, u, h, g = !1,
                    b = o.stickyClass || "",
                    v = o.unstickyClass || "",
                    y = o.bodyClass || "",
                    w = document.getElementsByTagName("sticky-scroll")[0] || t,
                    x = angular.element(t),
                    C = angular.element(w),
                    k = angular.element(document.body),
                    T = "false" !== o.usePlaceholder,
                    H = "bottom" === o.anchor ? "bottom" : "top",
                    M = "true" === o.confine,
                    z = o.offset ? parseInt(o.offset.replace(/px;?/, "")) : 0,
                    I = s.attr("style") || "",
                    W = {
                        zIndex: s.css("z-index"),
                        top: s.css("top"),
                        position: s.css("position"),
                        marginTop: s.css("margin-top"),
                        marginBottom: s.css("margin-bottom"),
                        cssLeft: s.css("left"),
                        height: s.css("height")
                    },
                    B = function() {
                        C.on("scroll", L), x.on("resize", e.$apply.bind(e, E)), e.$on("$destroy", $)
                    },
                    L = function() {
                        if ((e.disabled === !0 || d()) && g) return r();
                        var t, l = f() - (document.documentElement.clientTop || 0);
                        t = "top" === H ? M === !0 ? l > p && m >= l : l > p : p >= l;
                        var u = i(l, p, m);
                        !t || n(o.stickLimit) || g ? !t && g ? r(u, l) : M && !t && "bottom" === u && "absolute" !== s.css("position") && (h = a(s[0]), r(u, l)) : c(u)
                    },
                    $ = function() {
                        C.off("scroll", L), x.off("resize", E), k.removeClass(y), u && u.remove()
                    },
                    E = function() {
                        r(H), L()
                    },
                    P = function() {
                        return e.disabled === !0 ? r() : "top" === H ? (h || a(s[0])) - a(w) + f() : a(s[0]) - l() + s[0].offsetHeight + f()
                    },
                    O = function(t, e) {
                        if ((t !== e || "undefined" == typeof p) && !g) {
                            p = t - z, M && s.parent().css({
                                position: "relative"
                            });
                            var o = s.parent()[0],
                                n = parseInt(o.offsetHeight) - (T ? 0 : s[0].offsetHeight),
                                i = parseInt(s.css("margin-bottom").replace(/px;?/, "")) || 0,
                                r = a(s[0]),
                                c = a(o),
                                l = a(w),
                                d = r - l,
                                u = c + n - r;
                            m = d + u - s[0].offsetHeight - i - z + +f(), L()
                        }
                    };
                e.$watch(P, O), B()
            }
        }
    }]), window.matchMedia = window.matchMedia || function() {
        var t = "angular-sticky: This browser does not support matchMedia, therefore the minWidth option will not work on this browser. Polyfill matchMedia to fix this issue.";
        return window.console && console.warn && console.warn(t),
            function() {
                return {
                    matches: !0
                }
            }
    }()
	
	/*
	 ____  _____  _  ____  _  _____  _   _____ _      ____ 
	/ ___\/__ __\/ \/   _\/ |/ /\  \//  /  __// \  /|/  _ \
	|    \  / \  | ||  /  |   /  \  /   |  \  | |\ ||| | \|
	\___ |  | |  | ||  \_ |   \  / /    |  /_ | | \||| |_/|
	\____/  \_/  \_/\____/\_|\_\/_/     \____\\_/  \|\____/
	*/
	
	/*
	 ____  ____  ____  ____  _     _       _     ____    ____  _     _____  _____  ____  _        ____  _____  ____  ____  _____ 
	/ ___\/   _\/  __\/  _ \/ \   / \     / \ /\/  __\  /  _ \/ \ /\/__ __\/__ __\/  _ \/ \  /|  / ___\/__ __\/  _ \/  __\/__ __\
	|    \|  /  |  \/|| / \|| |   | |     | | |||  \/|  | | //| | ||  / \    / \  | / \|| |\ ||  |    \  / \  | / \||  \/|  / \  
	\___ ||  \_ |    /| \_/|| |_/\| |_/\  | \_/||  __/  | |_\\| \_/|  | |    | |  | \_/|| | \||  \___ |  | |  | |-|||    /  | |  
	\____/\____/\_/\_\\____/\____/\____/  \____/\_/     \____/\____/  \_/    \_/  \____/\_/  \|  \____/  \_/  \_/ \|\_/\_\  \_/  
	*/
	
	   directiveLibraryModule.directive('scrollup', function() {
	  return {
		restrict:'E',
		template:"<md-button class='md-raised' id=scrollme type='button' style='height:56px;width:56px;border-radius:56px;background-color: #3F51B5;color:white;'><div class='pull-down'></div>Go up</md-button>",
		link: function(scope,element){
			function scrollTo(o, l, c) {
				if (!(0 > c)) {
					var r = l - o.scrollTop,
						s = r / c * 10;
					setTimeout(function() {
						o.scrollTop = o.scrollTop + s, o.scrollTop !== l && scrollTo(o, l, c - 10)
					}, 10)
				}
			}

			function runScroll() {
				scrollTo(document.body, 0, 600)
			}

			function scrollTo(o, l, c) {
				if (!(0 > c)) {
					var r = l - o.scrollTop,
						s = r / c * 10;
					setTimeout(function() {
						o.scrollTop = o.scrollTop + s, o.scrollTop != l && scrollTo(o, l, c - 10)
					}, 10)
				}
			}
			var scrollme;
			scrollme = document.querySelector("#scrollme"), scrollme.addEventListener("click", runScroll, !1);
		}
	  }
	});
	
	/*
	 ____  ____  ____  ____  _     _       _     ____    ____  _     _____  _____  ____  _        _____ _      ____ 
	/ ___\/   _\/  __\/  _ \/ \   / \     / \ /\/  __\  /  _ \/ \ /\/__ __\/__ __\/  _ \/ \  /|  /  __// \  /|/  _ \
	|    \|  /  |  \/|| / \|| |   | |     | | |||  \/|  | | //| | ||  / \    / \  | / \|| |\ ||  |  \  | |\ ||| | \|
	\___ ||  \_ |    /| \_/|| |_/\| |_/\  | \_/||  __/  | |_\\| \_/|  | |    | |  | \_/|| | \||  |  /_ | | \||| |_/|
	\____/\____/\_/\_\\____/\____/\____/  \____/\_/     \____/\____/  \_/    \_/  \____/\_/  \|  \____\\_/  \|\____/
	*/
	
		directiveLibraryModule.provider('ngColorPickerConfig', function(){

		var templateUrl = 'partials/color-picker.html';
	   var defaultColors =  [
				'#1dd2af','#3498db','#9b59b6','#34495e','#27ae60','#2980b9','#8e44ad','#2c3e50','#f1c40f','#e67e22','#e74c3c','#95a5a6','#f39c12','#c0392b','#7f8c8d'
			];
		this.setTemplateUrl = function(url){
			templateUrl = url;
			return this;
		};
		this.setDefaultColors = function(colors){
			defaultColors = colors;
			return this;
		};
		this.$get = function(){
			return {
				templateUrl : templateUrl,
				defaultColors: defaultColors
			}
		}
	})
	directiveLibraryModule.directive('ngColorPicker', ['ngColorPickerConfig',function(ngColorPickerConfig) {
		
		return {
			scope: {
				selected: '=',
				customizedColors: '=colors'
			},
			restrict: 'AE',
			templateUrl: ngColorPickerConfig.templateUrl,
			link: function (scope, element, attr) {
				scope.colors = scope.customizedColors || ngColorPickerConfig.defaultColors;
				scope.selected = scope.selected || scope.colors[0];

				scope.pick = function (color) {
					scope.selected = color;
				};

			}
		};

	}]);

	directiveLibraryModule.service('uiInitilize', function(){
		this.insertIndex = function(array) {
			
			 for(var i=0; i<array.length; i++){
				  array[i].$index   = i;
			  }
			
			return array;
		};
	});
	
})(window.angular);